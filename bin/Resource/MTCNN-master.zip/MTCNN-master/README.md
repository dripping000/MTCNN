# MTCNN
MTCNN face detection implementation base on NCNN

![image](https://github.com/cpuimage/MTCNN/blob/master/result.jpg)

caffe模型转换参照项目:

https://github.com/ElegantGod/ncnn

NCNN项目:

https://github.com/Tencent/ncnn

# Donate

If the project is useful to you, and you like it, you can buy me a beer.
===========================================================
 
### Alipay donate
![Scan QRCode donate me via Alipay](https://img2018.cnblogs.com/blog/824862/201809/824862-20180930223557236-1709972421.png)

**Scan QRCode donate me via Alipay**
 
### WeChat donate
![Scan QRCode donate me via WeChat](https://img2018.cnblogs.com/blog/824862/201809/824862-20180930223603138-1708589189.png)

**Scan QRCode donate me via WeChat**
